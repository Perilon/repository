<!DOCTYPE HTML>
<html>
<?php
// Flite Voice Synthesis Demo
require 'vendor/autoload.php';
require_once('php/geoplugin.class.php');
use Mailgun\Mailgun;

function clean_string($string) {
	$bad = array("content-type","bcc:","to:","cc:","href");
	return str_replace($bad,"",$string);
}
function unQuoteString($string) {
	$rstring = $string;
	if (substr($rstring, 0, 1) == "'") $rstring = substr($rstring, 1);
	$length = strlen($rstring) - 1;
	if (substr($rstring, $length) == "'") $rstring = substr($rstring, 0, $length);
	return $rstring;
}

	$user_name = '';
	$user_email = '';
	$user_voice = '';
	$user_sentence = '';
	$user_comments = '';
	
	if( isset($_POST['call_id']) ) {
			$user_name = unQuoteString( $_POST['name'] );
			$user_email = unQuoteString( $_POST['from'] );
			$user_voice = unQuoteString( $_POST['lang'] );
			$user_sentence = unQuoteString( $_POST['sentence'] );
			$user_comments = unQuoteString( $_POST['comment'] );
			
			$email_to = "suresh@hear2read.org";
			
			//Add language to email subject
			$user_language = '';
			switch ($user_voice) {
				case 'Hindi_Female_AXB.flitevox':
					$user_language = "Hindi";
					break;
				case 'Kannada_Female_SMJ.flitevox':
					$user_language = "Kannada";
					break;
				case 'Marathi_Male_AUP.flitevox':
					$user_language = "Marathi";
					break;
				case 'Tamil_Male_SKS.flitevox':
					$user_language = "Tamil";
				break;
				case 'Telugu_Female_KNR.flitevox':
					$user_language = "Telugu";
				break;
			}

			$email_subject = "Flite " . $user_language . " Demo Comment: "; 
			$ip_address = $_SERVER['REMOTE_ADDR'];
//			$geoplugin = new geoPlugin();
//			locate the IP
//			$geoplugin->locate();

			$error_message = "";
			$email_exp = '/^[A-Za-z0-9._%-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,4}$/';
			if(!preg_match($email_exp,$user_email)) {
				$error_message .= 'The Email Address you entered does not appear to be valid.<br />';//
			} else if(!filter_var($user_email,FILTER_VALIDATE_EMAIL)) {
				$error_message .='The Email Address you entered does not appear to be valid.<br />';
			}
			$string_exp = "/^[A-Za-z .'-]+$/";
			if(!preg_match($string_exp,$user_name)) {
				$error_message .= 'The First Name you entered does not appear to be valid.<br />';
			}
			if( $error_message == "") {
				
				$email_message .= "<p>From: ".clean_string($user_name)." (".clean_string($user_email).")</p>";
				$email_message .= "<p>IP Address: ".$ip_address."<br /><br /></p>";
//				$email_message .= "<pre>";
//				$email_message .= "    Geolocation results for {" . $geoplugin->ip . "}:
//					City: {" . $geoplugin->city . "}
//					Region: {" . $geoplugin->region . "}
//					Country Name: {" . $geoplugin->countryName . "}
//					Country Code: {" . $geoplugin->countryCode . "}";
//				$email_message .= "</pre>";
				$email_message .= "<p>Voice: ".clean_string(nl2br($user_voice))."</p><br />";
				$email_message .= "<p>Test Sentence: ".clean_string(nl2br($user_sentence))."</p><br />";
				$email_message .= "<p>Comments:</p><p>".clean_string(nl2br($user_comments))."</p>";

				// Instantiate the client
				$mgClient=new Mailgun('key-8ab8ad3cd5293bdb93c1b31ea8bb25cd');
				$domain="sandboxa915612f51ef4ecbb89f0ca2638e29ad.mailgun.org";
				// Send Message through mailgun
				$result=$mgClient->sendMessage("$domain",
									array(  'from'    => "postmaster@sandboxa915612f51ef4ecbb89f0ca2638e29ad.mailgun.org",
											'to'      => "<".$email_to.">",
											'subject' => $email_subject,
											'html'    => "<html>".$email_message."</html>"  ));
				if ($result) {
					$error_message .=  "Thank you for your comment.";
				} else {
					$error_message .= "<span style=\"color: red; text-align: center;\">An error has occured sending your message.</p><p>Please try contacting us directly at suresh[at]hear2read[dot]com.</span>";
				}
			}
		echo "<p style='margin-top:0;text-align:center;color:red;'>" . $error_message . "</p></html>";
		return;
	} else {
	?>
<!--
	Strongly Typed by HTML5 UP
	html5up.net | @n33co
	Free for personal and commercial use under the CCA 3.0 license (html5up.net/license)
-->
	<!-- Head -->
	<?php // include  'users.php'; ?>
	<?php include 'head.php';?>
	<?php $this_page = "TestSpeech-test/app.php"; ?>
		<div class="container">
			<div style="height: 527px; margin-bottom:0;padding-top:.5em;" class="project">
				<div style="width:18%;float:left">
					<!-- <p style="margin-top:0;color:#00548b;">Choose Voice: -->
						<h3>Voice: 
						<select id="voice" onchange="choose_voice()" style="float:left;">
							<option name="voice" value="">Choose Voice</option>
							<option name="voice" value="Hindi_Female_AXB.flitevox"<?php if ($user_voice == "Hindi_Female_AXB.flitevox") echo " checked";?>>Hindi Female AXB</option>
							<option name="voice" value="Kannada_Female_SMJ.flitevox"<?php if ($user_voice == "Kannada_Female_SMJ.flitevox") echo " checked";?>>Kannada Female SMJ</option>
							<option name="voice" value="Marathi_Male_AUP.flitevox"<?php if ($user_voice == "Marathi_Male_AUP.flitevox") echo " checked";?>>Marathi Male AUP</option>
							<option name="voice" value="Tamil_Male_SKS.flitevox"<?php if ($user_voice == "Tamil_Male_SKS.flitevox") echo " checked";?>>Tamil Male SKS</option>
							<option name="voice" value="Telugu_Female_KNR.flitevox">Telugu Female KNR</option>
						</select></h3>
						<p style='font-size:1em;color:#00548b;margin:0 .5em 0 .5em;text-align:left;'>
							<br />We are continuously improving the algorithms based on feedback from native speakers. Please use the feedback form if you find errors in the machine generated speech.
						</p>
					<span id="request-buttons" style="display:none; text-align:left;margin-top:0.5em;">
						<input type="submit" value="Speak!" onclick="play_tts();" style="vertical-align:top;margin:1em 0 1em 1.4em;"> &nbsp;&nbsp;
						<input type="submit" value="Download!" onclick="download_tts();" style="margin-bottom:1em;">
						<br />
						<span id="audio-controls" style="display:none;">
							<audio id="player"></audio>
							<a id="downloader" href="" download="flite.wav" target="_blank" style="display:none;"></a>
						</span>
						<span id="clear-button" style="display:none;text-align:left;">
							<input type="submit" value="Clear Sentence" onclick="new_sentence()">
						</span>
					</span>
				</div>
				<div style="width:80%;float:left">
					<span id='text-area' style="text-align:left;display:none;">
						<p style="color:#00548b;margin-top:0;">Voice: <span id="spoken-voice"></span>&nbsp;&nbsp;Select from <button type="button" onclick="show_examples()">Example Sentences</button>
						 or enter your own sentence (in the selected language)</p>
							<textarea style="float:left;width:90%;" oninput="text_entered()" maxlength="400" rows=4 cols=100 id="textarea" name="text"
								placeholder="Enter text (in the selected language) here."><?php echo $user_sentence;?></textarea>
					</span>
					<div id="comment-area" style="display:none;border:solid;border-width:.15em;border-color:#00548b;border-radius:15px;height:27.5em;">
						<h2 style="font-size:1.2em;margin-bottom:0;">Spoken Text Comment Form</h2>
						<h4 style="margin-left:1em;">Spoken Text:</h4>
						<div style="width:90%;border:solid;border-width:.1em;border-color:#00548b;border-radius:10px;height:6em;margin:0 2em 1em 2em">
							<p style="margin:0 .5em 0 .5em;font-size:.9em;line-height:1.5em;" id="spoken-text">This should not be here!</p>
						</div>
						<textarea maxlength="1000" rows=20 cols=90 id="user-comments" name="comments" placeholder="Enter your comments." style="width:90%;height:15em;overflow-y:scroll;float:left;margin-left:2em;"><?php echo $user_comments;?></textarea>
						<br />
						<input type="text" name="UserName" id="user-name" placeholder="Enter Your Name" <?php echo "value ='$user_name'";?>>
						<input type="email" name="Email" id="e-mail" placeholder="Enter Email Address" <?php echo "value = '$user_email'";?>>
						<input style="vertical-align:center;margin-top:1em;" type="submit" value="Send Comments" onclick="send_comments()">
						<div id='send-errors'><?php echo "<p style='text-align:center;margin-top:0;color:red;'>".$error_message."</p>"?></div>
					</div>
					<div id="example-area" style="display:none;width:90%;border:solid;border-width:.1em;border-color:#00548b;border-radius:10px;height:22em;overflow-y:scroll;margin:0 2em 1em 2em;text-align:left;font-size:1.2em;line-height:1.2em;padding:.5em;">
					</div>
				</div>
					
				</div>
			</div>
			<div style="margin-bottom:2em;">
				<h4 style="text-align:center;">Synthesis Powered by <a href="http://www.cmuflite.org">Flite</a>.</h4>
				<p style="text-align:center; margin-top:0;font-size:small;line-height:1.5em;">
					Demo Powered by <a href="http://www.github.com/happyalu/goflite">GoFlite</a>.
				</p>
			</div>
		</div>
		<!-- Footer -->
		<?php include 'footer.php';?>
	</body>
</html>
<?php
	}
?>
