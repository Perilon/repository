			<div id="footer-wrapper" class="container">
				<div id="copyright" class="container">
					<ul style="font-size: .75em; list-style: none; text-align: center; margin-left: 0; line-height: 1.4em;">
						<li>All Contents Copyright &copy; 2014 - 2015 Hear2Read.  All rights reserved.</li>
						<li>Hear2Read is a trademark of Suresh Bazaj.</li>
						<?php if ($this_page == 'solution.php')
							echo '<li>Apple&#174;, Bookshare&#174;, and Google&#174; are registered trademarks of
							Apple, Inc., Beneficent Technology, Inc., and Google, Inc., respectively.  Android is a trademark of Google, Inc. Other trademarks 
							and registered trademarks are the property of their respective owners.</li>';
						?>
						<li>Design: Timothy White (template by <a href="http://html5up.net">HTML5 UP</a>)</li>
					</ul>
				</div>
			</div>